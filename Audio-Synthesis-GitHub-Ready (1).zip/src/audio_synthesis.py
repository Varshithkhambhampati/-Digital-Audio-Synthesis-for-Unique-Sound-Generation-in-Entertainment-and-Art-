"""
Audio Synthesis for Unique Sounds in Entertainment and Digital Art

Creates a short synthesized sound using multiple digital waveforms,
applies an ADSR-style envelope, mixes the layers, and saves a WAV file.
"""

import os
import numpy as np
from scipy.io.wavfile import write


SAMPLE_RATE = 44100
DURATION = 4.0
OUTPUT_DIR = "output"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "unique_synthesized_sound.wav")


def sine_wave(frequency, duration, sample_rate):
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    return np.sin(2 * np.pi * frequency * t)


def square_wave(frequency, duration, sample_rate):
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    return np.sign(np.sin(2 * np.pi * frequency * t))


def saw_wave(frequency, duration, sample_rate):
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    return 2.0 * ((frequency * t) % 1.0) - 1.0


def create_envelope(length, attack=0.10, decay=0.20, sustain=0.65, release=0.50):
    envelope = np.ones(length)

    attack_samples = min(int(attack * SAMPLE_RATE), length)
    decay_samples = min(int(decay * SAMPLE_RATE), max(0, length - attack_samples))
    release_samples = min(int(release * SAMPLE_RATE), max(0, length - attack_samples - decay_samples))

    if attack_samples > 0:
        envelope[:attack_samples] = np.linspace(
            0.0, 1.0, attack_samples, endpoint=False
        )

    decay_start = attack_samples
    decay_end = attack_samples + decay_samples

    if decay_samples > 0:
        envelope[decay_start:decay_end] = np.linspace(
            1.0, sustain, decay_samples, endpoint=False
        )

    release_start = max(0, length - release_samples)

    if release_samples > 0:
        envelope[release_start:] = np.linspace(
            sustain, 0.0, release_samples
        )

    if release_start > decay_end:
        envelope[decay_end:release_start] = sustain

    return envelope


def normalize(audio):
    peak = np.max(np.abs(audio))

    if peak == 0:
        return audio

    return audio / peak


def create_sound():
    print("Generating digital sound...")

    layer1 = sine_wave(220, DURATION, SAMPLE_RATE)
    layer2 = square_wave(330, DURATION, SAMPLE_RATE)
    layer3 = saw_wave(440, DURATION, SAMPLE_RATE)

    # Weighted mixing of different waveforms
    audio = (
        0.55 * layer1 +
        0.25 * layer2 +
        0.20 * layer3
    )

    envelope = create_envelope(len(audio))
    audio = audio * envelope

    # Normalize to prevent clipping
    audio = normalize(audio)

    # Convert to 16-bit PCM WAV
    audio_16bit = np.int16(audio * 32767)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    write(OUTPUT_FILE, SAMPLE_RATE, audio_16bit)

    print("\nAudio generated successfully.")
    print("Sample Rate:", SAMPLE_RATE, "Hz")
    print("Duration:", DURATION, "seconds")
    print("Output:", OUTPUT_FILE)

    return audio


def analyze_audio(audio):
    rms = np.sqrt(np.mean(np.square(audio)))
    peak = np.max(np.abs(audio))

    print("\n===== Audio Analysis =====")
    print(f"RMS Amplitude: {rms:.4f}")
    print(f"Peak Amplitude: {peak:.4f}")
    print(f"Number of Samples: {len(audio)}")


def main():
    audio = create_sound()
    analyze_audio(audio)


if __name__ == "__main__":
    main()
