# Audio Synthesis for Unique Sounds

## Short Project Title

**Digital Audio Synthesis for Unique Sound Generation**

## Description

This Python project demonstrates digital audio synthesis for generating unique sound effects. It combines multiple mathematical waveforms, applies an amplitude envelope, mixes the signals, normalizes the result, and exports the final sound as a WAV file.

## Features

- Sine wave generation
- Square wave generation
- Sawtooth wave generation
- Waveform mixing
- ADSR-style amplitude envelope
- Audio normalization
- WAV file generation
- Basic audio analysis using RMS and peak amplitude

## Technologies

- Python
- NumPy
- SciPy
- Digital Signal Processing concepts

## Project Workflow

Waveform Generation
        |
        v
Signal Mixing
        |
        v
Amplitude Envelope
        |
        v
Normalization
        |
        v
WAV File
        |
        v
Audio Analysis

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python src/audio_synthesis.py
```

The generated audio file will be saved as:

```text
output/unique_synthesized_sound.wav
```

## Applications

- Entertainment
- Digital art
- Games
- Movie sound effects
- Creative audio generation

## Author

K. Varshith

B.Tech Artificial Intelligence and Machine Learning
Kommuri Pratap Reddy Institute of Technology
